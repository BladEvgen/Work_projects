from django.urls import path
from . import views

urlpatterns = [
    path("diagram/", views.speciality_api, name="speciality_api"),
    path("api/", views.api, name="api"),
]
