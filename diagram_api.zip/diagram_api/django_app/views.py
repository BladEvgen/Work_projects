from rest_framework.decorators import api_view
from rest_framework.response import Response

from .config import execute_query, get_database_connection


@api_view(http_method_names=["GET", "POST", "PUT", "PATCH", "DELETE"])
def api(request):
    return Response(data={"message": "OK"})


@api_view(["GET"])
def speciality_api(request):
    with get_database_connection() as conn:
        students_count = execute_query(
            conn, "SELECT COUNT(*) FROM users WHERE isStudent = 1"
        )
        bakalavr_OM_count = execute_query(
            conn,
            "SELECT COUNT(*) FROM users WHERE isStudent = 1 AND professionNameRU IN ('Общая медицина', 'Медицина')",
        )
        stom_count = execute_query(
            conn,
            "SELECT COUNT(*) FROM users WHERE isStudent = 1 AND professionNameRU = 'Стоматология'",
        )
        farm_count = execute_query(
            conn,
            "SELECT COUNT(*) FROM users WHERE isStudent = 1 AND professionNameRU = 'Фармация'",
        )
        small_faculty_count = execute_query(
            conn,
            "SELECT COUNT(*) FROM users WHERE isStudent = 1 AND professionNameRU IN ('Сестринское дело', 'Медико-профилактическое дело', 'Общественная здравоохранение (2)')",
        )
        rez_mag_doc_count = execute_query(
            conn,
            "SELECT COUNT(*) FROM users WHERE isStudent = 1 AND professionNameRU NOT IN ('Общая медицина', 'Медицина', 'Стоматология', 'Фармация', 'Сестринское дело', 'Медико-профилактическое дело', 'Общественная здравоохранение (2)')",
        )

    response_data = {
        "diagram_1": {
            "students": students_count,
            "om": bakalavr_OM_count,
            "stom": stom_count,
            "farm": farm_count,
            "small_faculty": small_faculty_count,
            "rez_mag_doc": rez_mag_doc_count,
        }
    }

    return Response(response_data)
